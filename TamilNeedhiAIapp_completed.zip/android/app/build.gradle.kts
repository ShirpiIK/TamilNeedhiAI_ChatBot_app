plugins {

    id("com.android.application")

    id("kotlin-android")

    id("dev.flutter.flutter-gradle-plugin")

}

android {

    namespace = "com.tamilneedhiai.app"

    compileSdk = 35 // SDK 35 Update fixed

    ndkVersion = "27.0.12077973" // NDK Fix

    compileOptions {

        sourceCompatibility = JavaVersion.VERSION_1_8

        targetCompatibility = JavaVersion.VERSION_1_8

    }

    kotlinOptions {

        jvmTarget = "1.8"

    }

    defaultConfig {

        applicationId = "com.tamilneedhiai.app"

        minSdk = 21

        targetSdk = 35 // SDK 35 Update fixed

        versionCode = 1

        versionName = "1.0"

    }

    buildTypes {

        release {

            // --- FIX FOR "APP NOT INSTALLED" ---

            // ரிலீஸ் பில்டிலும் Debug Key-ஐ பயன்படுத்துகிறோம். 

            // அப்போதுதான் Play Store-ல் போடாமல் போனில் இன்ஸ்டால் செய்ய முடியும்.

            signingConfig = signingConfigs.getByName("debug")

            // --- FIX FOR BUILD ERRORS ---

            isMinifyEnabled = false

            isShrinkResources = false

            

            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

        }

    }

}

flutter {

    source = "../.."

}