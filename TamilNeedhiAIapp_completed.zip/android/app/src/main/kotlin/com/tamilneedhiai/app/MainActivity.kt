package com.tamilneedhiai.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
