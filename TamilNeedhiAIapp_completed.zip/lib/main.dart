// part 1
import 'dart:ui';

import 'dart:convert';

import 'dart:async';

import 'dart:io';

import 'dart:math';

import 'package:flutter/material.dart';

import 'package:flutter/services.dart'; // For HapticFeedback

import 'package:google_fonts/google_fonts.dart';

import 'package:http/http.dart' as http;

import 'package:shared_preferences/shared_preferences.dart';

import 'package:url_launcher/url_launcher.dart';

import 'package:image_picker/image_picker.dart';

import 'package:image_cropper/image_cropper.dart'; 

import 'package:animations/animations.dart';

import 'package:flutter_tts/flutter_tts.dart';

import 'package:speech_to_text/speech_to_text.dart' as stt;

import 'package:permission_handler/permission_handler.dart';

import 'package:path_provider/path_provider.dart';

import 'package:share_plus/share_plus.dart';

// --- GLOBAL VARIABLES ---

final ValueNotifier<bool> themeNotifier = ValueNotifier(false);

final ValueNotifier<String> langNotifier = ValueNotifier('English');

final ValueNotifier<double> fontSizeNotifier = ValueNotifier(16.0);

final ValueNotifier<double> pitchNotifier = ValueNotifier(1.0);

final ValueNotifier<double> rateNotifier = ValueNotifier(0.5);

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(

    statusBarColor: Colors.transparent,

  ));

  runApp(RootApp());

}

class RootApp extends StatefulWidget {

  @override

  _RootAppState createState() => _RootAppState();

}

class _RootAppState extends State<RootApp> {

  bool _isLoaded = false;

  bool _isLoggedIn = false;

  String _savedName = "";

  @override

  void initState() {

    super.initState();

    _loadPreferences();

  }

  Future<void> _loadPreferences() async {

    final prefs = await SharedPreferences.getInstance();

    themeNotifier.value = prefs.getBool('isDark') ?? false;

    langNotifier.value = prefs.getString('language') ?? 'English';

    fontSizeNotifier.value = prefs.getDouble('fontSize') ?? 16.0;

    pitchNotifier.value = prefs.getDouble('voicePitch') ?? 1.0;

    rateNotifier.value = prefs.getDouble('voiceRate') ?? 0.5;

    

    String? name = prefs.getString('userName');

    if (name != null && name.isNotEmpty) {

      _savedName = name;

      _isLoggedIn = true;

    }

    await Future.delayed(Duration(seconds: 2));

    if (mounted) setState(() { _isLoaded = true; });

  }

  @override

  Widget build(BuildContext context) {

    if (!_isLoaded) {

      var brightness = MediaQuery.platformBrightnessOf(context);

      bool isDarkMode = brightness == Brightness.dark;

      return MaterialApp(

        debugShowCheckedModeBanner: false,

        home: Scaffold(

          backgroundColor: isDarkMode ? Colors.black : Colors.white,

          body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

            Image.asset('assets/logo.png', width: 100, height: 100, errorBuilder: (c,o,s) => Icon(Icons.balance, size: 100, color: isDarkMode?Colors.white:Colors.black)), 

            SizedBox(height: 20), 

            CircularProgressIndicator(color: isDarkMode ? Colors.white : Colors.black)

          ])),

        ),

      );

    }

    return ValueListenableBuilder<String>(

      valueListenable: langNotifier,

      builder: (context, currentLang, child) {

        return ValueListenableBuilder<bool>(

          valueListenable: themeNotifier,

          builder: (context, isDark, child) {

            SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(

              statusBarColor: Colors.transparent,

              statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark, 

              systemNavigationBarColor: isDark ? Color(0xFF1E1E1E) : Color(0xFFF7F7F8),

              systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark,

            ));

            return ValueListenableBuilder<double>(

              valueListenable: fontSizeNotifier,

              builder: (context, fontSize, child) {

                return MaterialApp(

                  debugShowCheckedModeBanner: false,

                  title: 'Tamil Needhi AI',

                  themeMode: isDark ? ThemeMode.dark : ThemeMode.light,

                  builder: (context, child) {

                    final mediaQueryData = MediaQuery.of(context);

                    return MediaQuery(data: mediaQueryData.copyWith(textScaler: TextScaler.linear(fontSize / 16.0)), child: child!);

                  },

                  theme: ThemeData(brightness: Brightness.light, scaffoldBackgroundColor: Color(0xFFF7F7F8), primaryColor: Colors.black, textTheme: GoogleFonts.interTextTheme(ThemeData.light().textTheme), useMaterial3: true),

                  darkTheme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: Color(0xFF1E1E1E), primaryColor: Colors.white, textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme), useMaterial3: true),

                  home: _isLoggedIn ? ChatScreen(userName: _savedName) : OnboardingScreen(),

                );

              }

            );

          },

        );

      },

    );

  }

}

Future<void> saveSettings() async {

  final prefs = await SharedPreferences.getInstance();

  prefs.setBool('isDark', themeNotifier.value);

  prefs.setString('language', langNotifier.value);

  prefs.setDouble('fontSize', fontSizeNotifier.value);

  prefs.setDouble('voicePitch', pitchNotifier.value);

  prefs.setDouble('voiceRate', rateNotifier.value);

}

final Map<String, Map<String, String>> localized = {

  'English': {'welcome': 'Welcome to\nTamil Needhi AI', 'desc': 'Professional AI Legal Assistant.', 'get_started': 'Get Started', 'enter_name': 'Enter your Name', 'hint_name': 'Your Name', 'search': 'Search chat...', 'type_msg': 'Ask your legal query...', 'settings': 'Settings', 'appearance': 'Appearance', 'language': 'Language', 'font_size': 'Font Size', 'voice_settings': 'Voice Settings', 'history': 'History', 'about': 'About', 'user_details': 'User Details', 'clear_chat': 'Clear All Chats', 'version': 'Version 1.0', 'bot_error': 'Server Sleep. Retry.', 'no_net': 'No Internet Connection.', 'intro_text': 'Start your professional legal consultation.', 'select_lang': 'Choose Language', 'about_desc': 'Tamil Needhi AI helps citizens understand Indian Laws.', 'profile': 'Profile', 'change_photo': 'Tap to add photo', 'remove_photo': 'Remove Photo', 'logout': 'Log Out', 'dark_mode': 'Dark', 'light_mode': 'Light', 'search_settings': 'Search settings...', 'history_desc': 'Manage your chat history here.', 'deleted': 'History Cleared!', 'verify_law': 'Verify Law', 'sample_text': 'This is a sample text size.', 'privacy': 'Privacy Policy', 'help': 'Help & Support', 'listening': 'Listening...', 'test_voice': 'Test Voice'},

  'Tamil': {'welcome': 'தமிழ் நீதி AI\nவரவேற்கிறது', 'desc': 'உங்கள் தொழில்முறை சட்ட உதவியாளர்.', 'get_started': 'தொடங்கவும்', 'enter_name': 'உங்கள் பெயரை இடவும்', 'hint_name': 'பெயர்', 'search': 'தேடுக...', 'type_msg': 'சட்ட கேள்வியை கேட்கவும்...', 'settings': 'அமைப்புகள்', 'appearance': 'தோற்றம்', 'language': 'மொழி', 'font_size': 'எழுத்து அளவு', 'voice_settings': 'குரல் அமைப்புகள்', 'history': 'வரலாறு', 'about': 'பற்றி', 'user_details': 'பயனர் விவரங்கள்', 'clear_chat': 'அரட்டையை அழிக்கவும்', 'version': 'பதிப்பு 1.0', 'bot_error': 'சர்வர் தூக்கத்தில் உள்ளது.', 'no_net': 'இணைய இணைப்பு இல்லை.', 'intro_text': 'சட்ட ஆலோசனையைத் தொடங்குங்கள்.', 'select_lang': 'மொழியைத் தேர்ந்தெடுக்கவும்', 'about_desc': 'இந்தியச் சட்டங்களை புரிந்துகொள்ள உதவுகிறது.', 'profile': 'சுயவிவரம்', 'change_photo': 'படம் சேர்க்க தொடவும்', 'remove_photo': 'படத்தை நீக்கு', 'logout': 'வெளியேறு', 'dark_mode': 'இரவு', 'light_mode': 'பகல்', 'search_settings': 'அமைப்புகளைத் தேடு...', 'history_desc': 'உங்கள் அரட்டை வரலாறு.', 'deleted': 'வரலாறு அழிக்கப்பட்டது!', 'verify_law': 'சட்டம் சரிபார்', 'sample_text': 'இது எழுத்து அளவு மாதிரி.', 'privacy': 'தனியுரிமை', 'help': 'உதவி', 'listening': 'கேட்கிறது...', 'test_voice': 'குரல் சோதனை'},

  'Hindi': {'welcome': 'स्वागत है', 'desc': 'कानूनी सहायता', 'get_started': 'शुरू करें', 'enter_name': 'नाम दर्ज करें', 'hint_name': 'नाम', 'search': 'खोजें', 'type_msg': 'कानूनी सवाल पूछें...', 'settings': 'सेटिंग्स', 'appearance': 'दिखावट', 'language': 'भाषा', 'font_size': 'फ़ॉन्ट', 'voice_settings': 'आवाज़ सेटिंग्स', 'history': 'इतिहास', 'about': 'बारे में', 'user_details': 'विवरण', 'clear_chat': 'साफ़ करें', 'version': 'Ver 1.0', 'bot_error': 'त्रुटि', 'no_net': 'इंटरनेट नहीं है', 'intro_text': 'शुरू करें', 'select_lang': 'भाषा', 'about_desc': 'कानूनी सहायता', 'profile': 'प्रोफ़ाइल', 'change_photo': 'फोटो', 'remove_photo': 'हटाएं', 'logout': 'बाहर', 'dark_mode': 'डार्क', 'light_mode': 'लाइट', 'search_settings': 'खोजें...', 'history_desc': 'इतिहास', 'deleted': 'साफ़', 'verify_law': 'कानून जाँचें', 'sample_text': 'नमूना', 'privacy': 'गोपनीयता', 'help': 'मदद', 'listening': 'सुन रहा हूँ...', 'test_voice': 'आवाज़ परीक्षण'},

  'Telugu': {'welcome': 'స్వాగతం', 'desc': 'చట్టపరమైన సహాయం', 'get_started': 'ప్రారంభం', 'enter_name': 'పేరు', 'hint_name': 'పేరు', 'search': 'శోధన', 'type_msg': 'ప్రశ్న అడగండి...', 'settings': 'సెట్టింగ్‌లు', 'appearance': 'స్వరూపం', 'language': 'భాష', 'font_size': 'ఫాంట్', 'voice_settings': 'వాయిస్ సెట్టింగ్‌లు', 'history': 'చరిత్ర', 'about': 'గురించి', 'user_details': 'విവരాలు', 'clear_chat': 'క్లియర్', 'version': 'Ver 1.0', 'bot_error': 'లోపం', 'no_net': 'ఇంటర్నెట్ లేదు', 'intro_text': 'ప్రారంభం', 'select_lang': 'భాష', 'about_desc': 'సహాయం', 'profile': 'ప్రొఫైల్', 'change_photo': 'ఫోటో', 'remove_photo': 'తొలగించు', 'logout': 'లాగ్అవుట్', 'dark_mode': 'డార్క్', 'light_mode': 'లైట్', 'search_settings': 'శోధన...', 'history_desc': 'చరిత్ర', 'deleted': 'తొలగించబడింది', 'verify_law': 'చట్టాన్ని ధృవీకరించండి', 'sample_text': 'నమూనా', 'privacy': 'గోప్యత', 'help': 'సహాయం', 'listening': 'వినడం...', 'test_voice': 'వాయిస్ టెస్ట్'},

  'Malayalam': {'welcome': 'സ്വാഗതം', 'desc': 'നിയമ സഹായം', 'get_started': 'തുടങ്ങുക', 'enter_name': 'പേര്', 'hint_name': 'പേര്', 'search': 'തിരയുക', 'type_msg': 'ചോദിക്കൂ...', 'settings': 'ക്രമീകരണങ്ങൾ', 'appearance': 'രൂപം', 'language': 'ഭാഷ', 'font_size': 'ഫോണ്ട്', 'voice_settings': 'ശബ്ദ ക്രമീകരണങ്ങൾ', 'history': 'ചരിത്രം', 'about': 'കുറിച്ച്', 'user_details': 'വിവരങ്ങൾ', 'clear_chat': 'മായ്ക്കുക', 'version': 'Ver 1.0', 'bot_error': 'പിശക്', 'no_net': 'ഇന്റർനെറ്റ് ഇല്ല', 'intro_text': 'തുടങ്ങുക', 'select_lang': 'ഭാഷ', 'about_desc': 'സഹായം', 'profile': 'പ്രൊഫൈൽ', 'change_photo': 'ഫോട്ടോ', 'remove_photo': 'നീക്കം ചെയ്യുക', 'logout': 'പുറത്ത്', 'dark_mode': 'ഡാർക്ക്', 'light_mode': 'ലൈറ്റ്', 'search_settings': 'തിരയുക...', 'history_desc': 'ചരിത്രം', 'deleted': 'മായ്ച്ചു', 'verify_law': 'നിയമം പരിശോധിക്കുക', 'sample_text': 'മാതൃക', 'privacy': 'സ്വകാര്യത', 'help': 'സഹായം', 'listening': 'ശ്രദ്ധിക്കുന്നു...', 'test_voice': 'ശബ്ദ പരിശോധന'},

  'Kannada': {'welcome': 'ಸ್ವಾಗತ', 'desc': 'ಕಾನೂನು ನೆರವು', 'get_started': 'ಪ್ರಾರಂಭಿಸಿ', 'enter_name': 'ಹೆಸರು', 'hint_name': 'ಹೆಸರು', 'search': 'ಹುಡುಕಿ', 'type_msg': 'ಪ್ರಶ್ನೆ ಕೇಳಿ...', 'settings': 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು', 'appearance': 'ನೋಟ', 'language': 'ಭಾಷೆ', 'font_size': 'ಅಕ್ಷರ ಗಾತ್ರ', 'voice_settings': 'ಧ್ವನಿ ಸೆಟ್ಟಿಂಗ್‌ಗಳು', 'history': 'ಇತಿಹಾಸ', 'about': 'ಬಗ್ಗೆ', 'user_details': 'ವಿವರಗಳು', 'clear_chat': 'ತೆರವುಗೊಳಿಸಿ', 'version': 'Ver 1.0', 'bot_error': 'ದೋಷ', 'no_net': 'ಇಂಟರ್ನೆಟ್ ಇಲ್ಲ', 'intro_text': 'ಪ್ರಾರಂಭಿಸಿ', 'select_lang': 'ಭಾಷೆ', 'about_desc': 'ಕಾನೂನು ಸಹಾಯ', 'profile': 'ಪ್ರೊಫೈಲ್', 'change_photo': 'ಫೋಟೋ', 'remove_photo': 'ತೆಗೆದುಹಾಕಿ', 'logout': 'ಲಾಗ್ ಔಟ್', 'dark_mode': 'ಡಾರ್ಕ್', 'light_mode': 'ಲೈಟ್', 'search_settings': 'ಹುಡುಕಿ...', 'history_desc': 'ಇತಿಹಾಸ', 'deleted': 'ಅಳಿಸಲಾಗಿದೆ', 'verify_law': 'ಕಾನೂನು ಪರಿಶೀಲಿಸಿ', 'sample_text': 'ಮಾದರಿ ಪಠ್ಯ', 'privacy': 'ಗೌಪ್ಯತೆ', 'help': 'ಸಹಾಯ', 'listening': 'ಆಲಿಸಲಾಗುತ್ತಿದೆ...', 'test_voice': 'ಧ್ವನಿ ಪರೀಕ್ಷೆ'}

};

class OnboardingScreen extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return ValueListenableBuilder<String>(valueListenable: langNotifier, builder: (context, currentLang, _) {

      var t = localized[currentLang] ?? localized['English']!;

      bool isDark = themeNotifier.value;

      return Scaffold(resizeToAvoidBottomInset: false, body: Stack(children: [

        Container(color: isDark ? Colors.black : Colors.white),

        Positioned(top: -100, left: -100, child: Container(width: 300, height: 300, decoration: BoxDecoration(shape: BoxShape.circle, color: isDark ? Colors.blue.withOpacity(0.3) : Colors.blue.withOpacity(0.2)))),

        Positioned(bottom: -100, right: -100, child: Container(width: 300, height: 300, decoration: BoxDecoration(shape: BoxShape.circle, color: isDark ? Colors.purple.withOpacity(0.3) : Colors.orange.withOpacity(0.2)))),

        BackdropFilter(filter: ImageFilter.blur(sigmaX: 60, sigmaY: 60), child: Container(color: Colors.transparent)),

        Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

          Image.asset('assets/logo.png', width: 120, height: 120, errorBuilder: (c,o,s) => Icon(Icons.balance, size: 100, color: isDark ? Colors.white : Colors.black)),

          SizedBox(height: 30), Text(t['welcome']!, textAlign: TextAlign.center, style: GoogleFonts.inter(fontSize: 32, fontWeight: FontWeight.w800, color: isDark ? Colors.white : Colors.black, height: 1.2)), SizedBox(height: 15), Text(t['desc']!, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Colors.grey, fontWeight: FontWeight.w500)), SizedBox(height: 60), GestureDetector(onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => UsernameScreen())), child: Container(padding: EdgeInsets.symmetric(horizontal: 50, vertical: 18), decoration: BoxDecoration(gradient: LinearGradient(colors: isDark ? [Colors.blue, Colors.purple] : [Colors.black, Colors.grey.shade800]), borderRadius: BorderRadius.circular(30), boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 5))]), child: Text(t['get_started']!, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white))))]))

      ]));

    });

  }

}

class UsernameScreen extends StatefulWidget { @override _UsernameScreenState createState() => _UsernameScreenState(); }

class _UsernameScreenState extends State<UsernameScreen> {

  final TextEditingController _nameController = TextEditingController();

  @override Widget build(BuildContext context) {

    return ValueListenableBuilder<String>(valueListenable: langNotifier, builder: (context, currentLang, _) {

      var t = localized[currentLang] ?? localized['English']!; bool isDark = themeNotifier.value;

      return Scaffold(resizeToAvoidBottomInset: true, body: Stack(children: [Container(color: isDark ? Colors.black : Colors.white), Positioned(top: -50, right: -50, child: Container(width: 200, height: 200, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.teal.withOpacity(0.2)))), Positioned(bottom: 0, left: 0, child: Container(width: 200, height: 200, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.indigo.withOpacity(0.2)))), BackdropFilter(filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40), child: Container(color: Colors.transparent)), Padding(padding: EdgeInsets.symmetric(horizontal: 30), child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t['enter_name']!, style: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), SizedBox(height: 30), Container(padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.grey[100], borderRadius: BorderRadius.circular(15), border: Border.all(color: isDark ? Colors.grey[700]! : Colors.grey[300]!)), child: TextField(controller: _nameController, style: TextStyle(fontWeight: FontWeight.w600, color: isDark ? Colors.white : Colors.black), enableSuggestions: false, autocorrect: false, keyboardType: TextInputType.name, decoration: InputDecoration(hintText: t['hint_name']!, hintStyle: TextStyle(color: Colors.grey), border: InputBorder.none, icon: Icon(Icons.person_outline, color: Colors.grey)))), SizedBox(height: 40), Align(alignment: Alignment.centerRight, child: FloatingActionButton(backgroundColor: isDark ? Colors.white : Colors.black, child: Icon(Icons.arrow_forward_ios, color: isDark ? Colors.black : Colors.white), onPressed: () async { if (_nameController.text.isNotEmpty) { final prefs = await SharedPreferences.getInstance(); await prefs.setString('userName', _nameController.text); Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => ChatScreen(userName: _nameController.text))); } }))]))]));

    });

  }

}
// part 2
class ChatScreen extends StatefulWidget { final String userName; ChatScreen({required this.userName}); @override _ChatScreenState createState() => _ChatScreenState(); }

class _ChatScreenState extends State<ChatScreen> with SingleTickerProviderStateMixin {

  final TextEditingController _chatController = TextEditingController();

  final TextEditingController _searchController = TextEditingController();

  List<Map<String, dynamic>> messages = [];

  bool isLoading = false; 

  bool isSearching = false; 

  bool isTyping = false; 

  String searchQuery = "";

  final ScrollController _scrollController = ScrollController();

  

  late FlutterTts flutterTts;

  late stt.SpeechToText _speech;

  bool _isListening = false;

  String _isPlayingId = ""; // Stores which message is currently playing

  @override void initState() { 

    super.initState(); 

    _loadHistory();

    _initTts();

    _initSpeech();

  }

  void _initTts() {

    flutterTts = FlutterTts();

    // FIX: AUTO RESET INDIVIDUAL SPEAKER BUTTON

    flutterTts.setCompletionHandler(() { if(mounted) setState(() { _isPlayingId = ""; }); });

    flutterTts.setCancelHandler(() { if(mounted) setState(() { _isPlayingId = ""; }); });

    flutterTts.setErrorHandler((msg) { if(mounted) setState(() { _isPlayingId = ""; }); });

  }

  void _initSpeech() async {

    _speech = stt.SpeechToText();

  }

  Future<void> _speak(String text, String id) async {

    // If clicking the SAME button that is playing -> STOP IT

    if (_isPlayingId == id) {

      await flutterTts.stop();

      if(mounted) setState(() { _isPlayingId = ""; });

    } else {

      // Play new text

      await flutterTts.setPitch(pitchNotifier.value);

      await flutterTts.setSpeechRate(rateNotifier.value);

      if(mounted) setState(() { _isPlayingId = id; });

      await flutterTts.speak(text);

    }

  }

  // FIXED LOGIC: MAIN BOTTOM BUTTON ACTION

  Future<void> _handleStopOrSend() async {

    HapticFeedback.lightImpact();

    // 1. If Recording -> STOP Recording

    if (_isListening) {

      _speech.stop();

      setState(() => _isListening = false);

      return;

    }

    // NOTE: Removed TTS Stop logic from here as requested. 

    // The main button will NOT stop TTS anymore. Only the small button does.

    // 2. If Loading (Waiting for Network) -> CANCEL

    if (isLoading) {

      setState(() => isLoading = false);

      return;

    }

    // 3. If Typing (Animation Running) -> FORCE FINISH (Show full text immediately)

    if (isTyping) {

      setState(() {

        isTyping = false;

        if (messages.isNotEmpty) {

           messages.last['animated'] = true;

        }

      });

      return;

    }

    // 4. Else -> SEND Message

    sendMessage(_chatController.text);

  }

  Future<void> _listen() async {

    HapticFeedback.mediumImpact(); 

    SystemSound.play(SystemSoundType.click);

    

    if (!_isListening) {

      bool available = await _speech.initialize(onStatus: (val) => print('onStatus: $val'), onError: (val) => print('onError: $val'));

      if (available) {

        setState(() => _isListening = true);

        _speech.listen(onResult: (val) => setState(() {

          _chatController.text = val.recognizedWords;

          if(val.finalResult) { _isListening = false; }

        }));

      }

    } else {

      setState(() => _isListening = false);

      _speech.stop();

    }

  }

  Future<void> _saveHistory() async { final prefs = await SharedPreferences.getInstance(); prefs.setString('chat_history', jsonEncode(messages)); }

  

  Future<void> _loadHistory() async { 

    final prefs = await SharedPreferences.getInstance(); 

    String? history = prefs.getString('chat_history'); 

    if (history != null) { 

      setState(() { 

        List<dynamic> decoded = jsonDecode(history); 

        messages = decoded.map((e) {

          final m = Map<String, dynamic>.from(e);

          m['animated'] = true; 

          return m;

        }).toList(); 

      }); 

      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom(force: true)); 

    } 

  }

  void _clearHistory() async { final prefs = await SharedPreferences.getInstance(); prefs.remove('chat_history'); setState(() { messages.clear(); }); }

  

  void _scrollToBottom({bool force = false}) {

    if (_scrollController.hasClients) {

      final position = _scrollController.position;

      if (force || position.maxScrollExtent - position.pixels <= 100) {

        Future.delayed(Duration(milliseconds: 50), () {

          if(_scrollController.hasClients) _scrollController.jumpTo(_scrollController.position.maxScrollExtent);

        });

      }

    }

  }

  Future<void> sendMessage(String text) async {

    if (text.trim().isEmpty) return;

    var t = localized[langNotifier.value]!;

    

    setState(() { messages.add({"role": "user", "content": text, "animated": true}); isLoading = true; });

    _saveHistory(); _chatController.clear(); _scrollToBottom(force: true);

    

    String conversationHistory = "";

    int start = messages.length > 10 ? messages.length - 10 : 0; 

    for (int i = start; i < messages.length; i++) {

       String role = messages[i]['role'] == 'user' ? "User" : "AI";

       String content = messages[i]['content'].toString().replaceAll("\n", " ");

       conversationHistory += "$role: $content\n";

    }

    String prompt = """

    SYSTEM IDENTITY: You are 'Tamil Needhi AI'.

    HISTORY: $conversationHistory

    USER: $text

    INSTRUCTIONS: Answer accurately using Indian Law. Reply in the same language.

    """;

    String url = "https://16770160-d8a5-4144-9853-0a025c1c37aa-00-287rrysolhln6.sisko.replit.dev/ask";

    try {

      final response = await http.post(Uri.parse(url), headers: {"Content-Type": "application/json"}, 

        body: jsonEncode({"question": prompt}) 

      ).timeout(Duration(seconds: 40));

      

      if (!isLoading) return; 

      if (response.statusCode == 200) { 

        var data = jsonDecode(response.body); 

        setState(() { 

          messages.add({"role": "ai", "content": data['answer'], "links": data['links'], "animated": false}); 

          isTyping = true; // Shows Stop button at bottom ONLY for Typing

        }); 

      } 

      else { setState(() { messages.add({"role": "ai", "content": "${t['bot_error']} (Code: ${response.statusCode})", "animated": false}); }); }

    } catch (e) {

      if (!isLoading) return; 

      String errorMsg = t['bot_error']!;

      if (e.toString().contains("SocketException")) errorMsg = t['no_net']!;

      setState(() { messages.add({"role": "ai", "content": errorMsg, "animated": false}); });

    } finally { setState(() { isLoading = false; }); _saveHistory(); }

  }

  void _showVerifyPopup(Map<String, dynamic> links) {

    bool isDark = themeNotifier.value;

    showModalBottomSheet(

      context: context,

      backgroundColor: Colors.transparent,

      builder: (context) => Container(

        decoration: BoxDecoration(color: isDark ? Color(0xFF1E1E1E) : Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(25))),

        padding: EdgeInsets.all(25),

        child: Column(mainAxisSize: MainAxisSize.min, children: [

          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[400], borderRadius: BorderRadius.circular(2))),

          SizedBox(height: 20),

          Text("Verify Law", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)),

          SizedBox(height: 10),

          Text("Choose a trusted source to verify:", style: TextStyle(color: Colors.grey)),

          SizedBox(height: 20),

          _buildVerifyTile("India Code", links["India Code"], Icons.account_balance, Colors.blue),

          _buildVerifyTile("Indian Kanoon", links["Indian Kanoon"], Icons.gavel, Colors.orange),

          _buildVerifyTile("Devgan.in", links["Devgan.in"], Icons.library_books, Colors.green),

          SizedBox(height: 10),

        ]),

      )

    );

  }

  Widget _buildVerifyTile(String title, String? url, IconData icon, Color color) {

    bool isDark = themeNotifier.value;

    return ListTile(

      leading: Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color)),

      title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)),

      trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),

      onTap: () {

        Navigator.pop(context);

        if (url != null && url.isNotEmpty) launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

      },

    );

  }

  @override Widget build(BuildContext context) {

    return ValueListenableBuilder<String>(valueListenable: langNotifier, builder: (context, currentLang, _) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) {

      var t = localized[currentLang] ?? localized['English']!; 

      List<Map<String, dynamic>> displayedMessages = searchQuery.isEmpty ? messages : messages.where((m) => m['content'].toString().toLowerCase().contains(searchQuery.toLowerCase())).toList();

      

      return AnnotatedRegion<SystemUiOverlayStyle>(

        value: SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark, systemNavigationBarColor: isDark ? Color(0xFF1E1E1E) : Color(0xFFF7F7F8), systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark),

        child: Scaffold(backgroundColor: isDark ? Color(0xFF1E1E1E) : Color(0xFFF7F7F8), body: Stack(children: [

          Column(children: [

            Expanded(child: displayedMessages.isEmpty && searchQuery.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

              Container(padding: EdgeInsets.all(20), margin: EdgeInsets.symmetric(horizontal: 40), decoration: BoxDecoration(gradient: LinearGradient(colors: isDark ? [Colors.grey[900]!, Colors.black] : [Colors.white, Colors.grey[100]!], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 15, offset: Offset(0, 5))]), child: Column(children: [Image.asset('assets/logo.png', width: 60, height: 60, errorBuilder: (c,o,s)=>Icon(Icons.balance, size:60, color:isDark?Colors.white:Colors.black)), SizedBox(height: 20), Text("Welcome, ${widget.userName}", style: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), SizedBox(height: 10), Text(t['intro_text']!, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 14))]))

            ])) : 

            ShaderMask(

                shaderCallback: (Rect bounds) { return LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black, Colors.black, Colors.transparent], stops: [0.0, 0.15, 0.90, 1.0]).createShader(bounds); },

                blendMode: BlendMode.dstIn,

                child: ListView.builder(

                  controller: _scrollController,

                  physics: BouncingScrollPhysics(),

                  padding: EdgeInsets.only(top: 130, bottom: 100, left: 15, right: 15), 

                  itemCount: displayedMessages.length + (isLoading ? 1 : 0), 

                  itemBuilder: (context, index) { 

                    if (index == displayedMessages.length && isLoading) return Align(alignment: Alignment.centerLeft, child: _buildLoadingDots(isDark)); 

                    final msg = displayedMessages[index]; final isUser = msg['role'] == "user"; 

                    return SlideInMessage(

                      isUser: isUser,

                      child: isUser 

                        ? Align(alignment: Alignment.centerRight, child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [

                            Container(constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8), margin: EdgeInsets.symmetric(vertical: 8), padding: EdgeInsets.symmetric(horizontal: 18, vertical: 14), decoration: BoxDecoration(color: isDark ? Colors.white : Colors.black, borderRadius: BorderRadius.circular(20)), child: Text(msg['content'].toString(), style: TextStyle(height: 1.5, fontWeight: FontWeight.w600, color: isDark ? Colors.black : Colors.white))),

                            Padding(padding: EdgeInsets.only(right: 5), child: GestureDetector(onTap: () { Clipboard.setData(ClipboardData(text: msg['content'])); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Copied!"))); }, child: Icon(Icons.copy, size: 14, color: Colors.grey))),

                          ]))

                        : Align(alignment: Alignment.centerLeft, child: Container(margin: EdgeInsets.symmetric(vertical: 10), padding: EdgeInsets.only(right: 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                            msg['animated'] == true 

                              ? Text(msg['content'].toString(), style: TextStyle(height: 1.8, fontWeight: FontWeight.w600, color: isDark ? Colors.white : Colors.black87, fontSize: 16)) 

                              : TypewriterText(text: msg['content'].toString(), style: TextStyle(height: 1.8, fontWeight: FontWeight.w600, color: isDark ? Colors.white : Colors.black87, fontSize: 16), onFinished: () { setState(() { msg['animated'] = true; isTyping = false; }); }, onType: () => _scrollToBottom(force: false)), 

                            

                            if (msg['animated'] == true) ...[

                              SizedBox(height: 15),

                              Row(children: [

                                // FIX: ONLY THIS SMALL BUTTON TOGGLES BETWEEN PLAY/STOP

                                GestureDetector(

                                  onTap: () => _speak(msg['content'], index.toString()), 

                                  child: Icon(

                                    _isPlayingId == index.toString() ? Icons.stop_circle : Icons.volume_up_rounded, 

                                    size: 20, 

                                    color: Colors.grey

                                  )

                                ),

                                SizedBox(width: 20),

                                GestureDetector(onTap: () { Clipboard.setData(ClipboardData(text: msg['content'])); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Copied!"))); }, child: Icon(Icons.copy, size: 18, color: Colors.grey)),

                                SizedBox(width: 20),

                                GestureDetector(onTap: () { Share.share(msg['content']); }, child: Icon(Icons.share, size: 18, color: Colors.grey)),

                                SizedBox(width: 20),

                                if(msg.containsKey('links') && msg['links'] != null) GestureDetector(onTap: () => _showVerifyPopup(msg['links']), child: Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(border: Border.all(color: Colors.blue.withOpacity(0.5)), borderRadius: BorderRadius.circular(15)), child: Row(children: [Icon(Icons.verified, size: 12, color: Colors.blue), SizedBox(width: 5), Text(t['verify_law']!, style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 10))]))),

                              ])

                            ]

                          ])))

                    );

                  } 

                ),

              )

            ),

          ]),

          Positioned(bottom: 0, left: 0, right: 0, child: Container(padding: EdgeInsets.fromLTRB(15, 10, 15, 20), color: Colors.transparent, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [

            Expanded(child: Container(constraints: BoxConstraints(minHeight: 45, maxHeight: 160), padding: EdgeInsets.symmetric(horizontal: 15), decoration: BoxDecoration(color: isDark ? Colors.black : Colors.white, borderRadius: BorderRadius.circular(25), border: Border.all(color: isDark ? Colors.white24 : Colors.black12, width: 1.0), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 5))]), child: TextField(controller: _chatController, keyboardType: TextInputType.multiline, maxLines: null, textCapitalization: TextCapitalization.sentences, style: TextStyle(color: isDark ? Colors.white : Colors.black, fontWeight: FontWeight.w600, fontSize: 15), decoration: InputDecoration(hintText: _isListening ? t['listening'] : t['type_msg'], hintStyle: TextStyle(color: _isListening ? Colors.red : Colors.grey, fontSize: 15), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12), isDense: true)))), 

            SizedBox(width: 10), 

            // MIC BUTTON CENTER ALIGNMENT

            GestureDetector(onTap: _listen, child: Container(

              height: 45, width: 45, alignment: Alignment.center,

              child: _isListening 

              ? SineWaveVisualizer(color: Colors.red, isStatic: false)

              : CircleAvatar(radius: 22, backgroundColor: isDark ? Colors.grey[800] : Colors.grey[200], child: Icon(Icons.mic_none, color: isDark ? Colors.white : Colors.black, size: 22))

            )),

            SizedBox(width: 10),

            // FIX: MAIN BUTTON DOES NOT CHANGE TO STOP FOR TTS. ONLY FOR MIC/LOADING/TYPING.

            GestureDetector(

              onTap: _handleStopOrSend, 

              child: CircleAvatar(

                radius: 22, 

                backgroundColor: isDark ? Colors.white : Colors.black, 

                child: Icon(

                  (_isListening || isLoading || isTyping) ? Icons.stop_rounded : Icons.arrow_upward_rounded, 

                  color: isDark ? Colors.black : Colors.white, 

                  size: 22

                )

              )

            )

          ]))),

          if (!isSearching) Positioned(top: 50, left: 20, right: 20, child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [_buildGlassyIcon(Icons.settings, isDark, () => _openSettingsPage(context)), ClipRRect(borderRadius: BorderRadius.circular(20), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10), decoration: BoxDecoration(color: isDark ? Colors.white.withOpacity(0.1) : Colors.black.withOpacity(0.05), borderRadius: BorderRadius.circular(20), border: Border.all(color: isDark ? Colors.white10 : Colors.black12)), child: Text("Tamil Needhi AI", style: GoogleFonts.inter(fontWeight: FontWeight.bold, fontSize: 16, color: isDark ? Colors.white : Colors.black))))), _buildGlassyIcon(Icons.search, isDark, () => setState(() { isSearching = true; }))])),

          if (isSearching) Positioned(top: 50, left: 20, right: 20, child: ClipRRect(borderRadius: BorderRadius.circular(25), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(height: 50, decoration: BoxDecoration(color: isDark ? Colors.white.withOpacity(0.1) : Colors.black.withOpacity(0.05), borderRadius: BorderRadius.circular(25), border: Border.all(color: isDark ? Colors.white10 : Colors.black12)), child: TextField(controller: _searchController, autofocus: true, textAlignVertical: TextAlignVertical.center, style: TextStyle(color: isDark ? Colors.white : Colors.black), onChanged: (val) => setState(() => searchQuery = val), decoration: InputDecoration(prefixIcon: Icon(Icons.search, color: Colors.grey), hintText: t['search'], hintStyle: TextStyle(color: Colors.grey), border: InputBorder.none, suffixIcon: IconButton(icon: Icon(Icons.close, color: Colors.grey), onPressed: () => setState(() { isSearching = false; searchQuery = ""; }))))))))

        ]))

      );

    });});

  }

  Widget _buildGlassyIcon(IconData icon, bool isDark, VoidCallback onTap) { return GestureDetector(onTap: onTap, child: ClipRRect(borderRadius: BorderRadius.circular(50), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(padding: EdgeInsets.all(12), decoration: BoxDecoration(color: isDark ? Colors.white.withOpacity(0.1) : Colors.black.withOpacity(0.05), shape: BoxShape.circle, border: Border.all(color: isDark ? Colors.white10 : Colors.black12)), child: Icon(icon, size: 22, color: isDark ? Colors.white : Colors.black))))); }

  Widget _buildLoadingDots(bool isDark) { return Container(margin: EdgeInsets.symmetric(vertical: 10), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.circle, size: 8, color: Colors.grey), SizedBox(width: 5), Icon(Icons.circle, size: 8, color: Colors.grey), SizedBox(width: 5), Icon(Icons.circle, size: 8, color: Colors.grey)])); }

  void _openSettingsPage(BuildContext context) { Navigator.of(context).push(_createRoute(SettingsPage(clearHistory: _clearHistory, userName: widget.userName))); }

}

class SlideInMessage extends StatelessWidget { final Widget child; final bool isUser; SlideInMessage({required this.child, required this.isUser}); @override Widget build(BuildContext context) { return TweenAnimationBuilder(tween: Tween<double>(begin: 0, end: 1), duration: Duration(milliseconds: 400), curve: Curves.easeOutQuart, builder: (context, double val, child) { return Opacity(opacity: val, child: Transform.translate(offset: Offset(0, 20 * (1 - val)), child: child)); }, child: child); } }

class TypewriterText extends StatefulWidget { final String text; final TextStyle style; final VoidCallback onFinished; final VoidCallback? onType; const TypewriterText({required this.text, required this.style, required this.onFinished, this.onType}); 

  @override 

  _TypewriterTextState createState() => _TypewriterTextState(); 

}

class _TypewriterTextState extends State<TypewriterText> { String displayedText = ""; int charIndex = 0; Timer? _timer; @override void initState() { super.initState(); _startTyping(); } void _startTyping() { _timer = Timer.periodic(Duration(milliseconds: 10), (timer) { if (charIndex < widget.text.length) { setState(() { displayedText += widget.text[charIndex]; charIndex++; }); if(widget.onType != null && charIndex % 5 == 0) widget.onType!(); } else { timer.cancel(); widget.onFinished(); } }); } @override void dispose() { _timer?.cancel(); super.dispose(); } @override Widget build(BuildContext context) { return Text(displayedText, style: widget.style); } }

Route _createRoute(Widget page) { return PageRouteBuilder(pageBuilder: (context, animation, secondaryAnimation) => page, transitionsBuilder: (context, animation, secondaryAnimation, child) { const begin = Offset(1.0, 0.0); const end = Offset.zero; const curve = Curves.easeInOutCubic; var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve)); return SlideTransition(position: animation.drive(tween), child: child); }); }
// part 3
// --- SETTINGS PAGES ---

class SettingsPage extends StatefulWidget { final VoidCallback clearHistory; final String userName; SettingsPage({required this.clearHistory, required this.userName}); @override _SettingsPageState createState() => _SettingsPageState(); }

class _SettingsPageState extends State<SettingsPage> {

  String searchText = ""; final TextEditingController _searchCtrl = TextEditingController();

  @override Widget build(BuildContext context) {

    return ValueListenableBuilder<String>(valueListenable: langNotifier, builder: (context, currentLang, _) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) {

      var t = localized[currentLang] ?? localized['English']!;

      return AnnotatedRegion<SystemUiOverlayStyle>(

        value: SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark, systemNavigationBarColor: isDark ? Colors.black : Color(0xFFF2F2F7), systemNavigationBarIconBrightness: isDark ? Brightness.light : Brightness.dark),

        child: Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context)), title: Text(t['settings']!, style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), centerTitle: true),

          body: Column(children: [Container(margin: EdgeInsets.all(20), padding: EdgeInsets.symmetric(horizontal: 15), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, borderRadius: BorderRadius.circular(15)), child: TextField(controller: _searchCtrl, textAlignVertical: TextAlignVertical.center, style: TextStyle(color: isDark ? Colors.white : Colors.black, fontWeight: FontWeight.bold), onChanged: (val) => setState(() => searchText = val), decoration: InputDecoration(icon: Icon(Icons.search, color: Colors.grey), hintText: t['search_settings'], hintStyle: TextStyle(color: Colors.grey), border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 15), suffixIcon: searchText.isNotEmpty ? IconButton(icon: Icon(Icons.close, color: Colors.grey), onPressed: (){ setState(() { searchText = ""; _searchCtrl.clear(); }); }) : null))),

            Expanded(child: ScrollConfiguration(behavior: ScrollBehavior().copyWith(overscroll: false), child: ListView(padding: EdgeInsets.symmetric(horizontal: 20), children: [

              _buildSettingsCard(context, Icons.person_outline, t['user_details']!, widget.userName, isDark: isDark, onTap: () => Navigator.push(context, _createRoute(UserDetailsPage(userName: widget.userName)))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.palette_outlined, t['appearance']!, isDark ? t['dark_mode']! : t['light_mode']!, isDark: isDark, onTap: () => Navigator.push(context, _createRoute(AppearancePage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.record_voice_over, t['voice_settings']!, "Pitch & Rate", isDark: isDark, onTap: () => Navigator.push(context, _createRoute(VoiceSettingsPage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.language_outlined, t['language']!, currentLang, isDark: isDark, onTap: () => Navigator.push(context, _createRoute(LanguagePage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.text_fields, t['font_size']!, "Aa", isDark: isDark, onTap: () => Navigator.push(context, _createRoute(FontSizePage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.history, t['history']!, t['clear_chat']!, isDark: isDark, onTap: () => Navigator.push(context, _createRoute(HistoryPage(clearHistory: widget.clearHistory)))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.info_outline, t['about']!, t['version']!, isDark: isDark, onTap: () => Navigator.push(context, _createRoute(AboutPage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.lock_outline, t['privacy']!, "", isDark: isDark, onTap: () => Navigator.push(context, _createRoute(PrivacyPage()))), SizedBox(height: 10),

              _buildSettingsCard(context, Icons.help_outline, t['help']!, "", isDark: isDark, onTap: () => Navigator.push(context, _createRoute(HelpPage()))), 

              SizedBox(height: 40), 

            ])))

          ]))

      );

    });});

  }

  Widget _buildSettingsCard(BuildContext context, IconData icon, String title, String subtitle, {VoidCallback? onTap, required bool isDark}) { if (searchText.isNotEmpty && !title.toLowerCase().contains(searchText.toLowerCase())) return SizedBox.shrink(); return GestureDetector(onTap: onTap, child: Container(height: 60, padding: EdgeInsets.symmetric(horizontal: 15), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: isDark ? Colors.transparent : Colors.grey.shade200)), child: Row(children: [Container(padding: EdgeInsets.all(10), decoration: BoxDecoration(color: isDark ? Colors.black : Color(0xFFF2F2F7), borderRadius: BorderRadius.circular(12)), child: Icon(icon, size: 20, color: isDark ? Colors.white : Colors.black)), SizedBox(width: 15), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(title, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), if(subtitle.isNotEmpty) ...[SizedBox(height: 2), Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey))]])), Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey)]))); }

}

class VoiceSettingsPage extends StatefulWidget { @override _VoiceSettingsPageState createState() => _VoiceSettingsPageState(); }

class _VoiceSettingsPageState extends State<VoiceSettingsPage> {

  FlutterTts flutterTts = FlutterTts();

  bool isPlaying = false; 

  @override void initState() { super.initState(); 

    flutterTts.setCompletionHandler(() { setState(() { isPlaying = false; }); });

  }

  

  @override Widget build(BuildContext context) {

    return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) {

      var t = localized[langNotifier.value]!;

      return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text(t['voice_settings']!, style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), 

        body: Padding(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          Text("Pitch", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),

          ValueListenableBuilder<double>(valueListenable: pitchNotifier, builder: (context, val, _) {

            return Slider(value: val, min: 0.5, max: 2.0, onChanged: (v) { pitchNotifier.value = v; saveSettings(); });

          }),

          Text("Speed (Rate)", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),

          ValueListenableBuilder<double>(valueListenable: rateNotifier, builder: (context, val, _) {

            return Slider(value: val, min: 0.0, max: 1.0, onChanged: (v) { rateNotifier.value = v; saveSettings(); });

          }),

          SizedBox(height: 40),

          Center(child: GestureDetector(

            onTap: () async { 

              setState(() { isPlaying = true; });

              await flutterTts.speak("This is a test voice.");

            },

            child: Container(

              height: 50, width: 150,

              decoration: BoxDecoration(color: isDark ? Colors.white : Colors.black, borderRadius: BorderRadius.circular(25)),

              child: isPlaying 

                ? SineWaveVisualizer(color: isDark ? Colors.black : Colors.white, isStatic: false)

                : Center(child: Text(t['test_voice']!, style: TextStyle(color: isDark ? Colors.black : Colors.white, fontWeight: FontWeight.bold)))

            )

          ))

        ]))

      );

    });

  }

}

class SineWaveVisualizer extends StatefulWidget { final Color color; final bool isStatic; SineWaveVisualizer({required this.color, required this.isStatic}); @override _SineWaveVisualizerState createState() => _SineWaveVisualizerState(); }

class _SineWaveVisualizerState extends State<SineWaveVisualizer> with SingleTickerProviderStateMixin {

  late AnimationController _controller;

  @override void initState() { super.initState(); _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 1000))..repeat(); }

  @override void dispose() { _controller.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {

    if(widget.isStatic) return SizedBox.shrink();

    return AnimatedBuilder(animation: _controller, builder: (context, child) {

      return Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (index) {

        return Container(margin: EdgeInsets.symmetric(horizontal: 2), width: 4, height: 10 + 15 * sin(_controller.value * 2 * pi + index), decoration: BoxDecoration(color: widget.color, borderRadius: BorderRadius.circular(2)));

      }));

    });

  }

}

class AppearancePage extends StatelessWidget { @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { var t = localized[langNotifier.value]!; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text(t['appearance']!, style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Padding(padding: EdgeInsets.all(20), child: Row(children: [Expanded(child: _buildVisualCard(context, t['light_mode']!, Icons.wb_sunny_outlined, false, isDark, () { themeNotifier.value = false; saveSettings(); })), SizedBox(width: 15), Expanded(child: _buildVisualCard(context, t['dark_mode']!, Icons.nightlight_round, true, isDark, () { themeNotifier.value = true; saveSettings(); }))]))); }); } Widget _buildVisualCard(BuildContext context, String title, IconData icon, bool isDarkOption, bool currentThemeIsDark, VoidCallback onTap) { bool isSelected = isDarkOption == currentThemeIsDark; return GestureDetector(onTap: onTap, child: Container(height: 180, decoration: BoxDecoration(color: isDarkOption ? Colors.black : Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: isSelected ? Colors.blue : Colors.transparent, width: 3), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 5))]), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 40, color: isDarkOption ? Colors.white : Colors.black), SizedBox(height: 15), Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: isDarkOption ? Colors.white : Colors.black)), if (isSelected) Padding(padding: EdgeInsets.only(top: 10), child: Icon(Icons.check_circle, color: Colors.blue))]))); } }

class LanguagePage extends StatelessWidget { @override Widget build(BuildContext context) { return ValueListenableBuilder<String>(valueListenable: langNotifier, builder: (context, currentLang, _) { bool isDark = themeNotifier.value; var t = localized[currentLang]!; List<String> langs = ['English', 'Tamil', 'Hindi', 'Telugu', 'Malayalam', 'Kannada']; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text(t['select_lang']!, style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: ListView.separated(padding: EdgeInsets.all(20), itemCount: langs.length, separatorBuilder: (c, i) => SizedBox(height: 15), itemBuilder: (context, index) { bool isSelected = langs[index] == currentLang; return GestureDetector(onTap: () { langNotifier.value = langs[index]; saveSettings(); Navigator.pop(context); }, child: Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: isSelected ? Colors.blue : Colors.transparent, width: 2)), child: Row(children: [Text(langs[index], style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), Spacer(), if (isSelected) Icon(Icons.check_circle, color: Colors.blue)]))); })); }); } }

class FontSizePage extends StatefulWidget { @override _FontSizePageState createState() => _FontSizePageState(); }

class _FontSizePageState extends State<FontSizePage> { @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { var t = localized[langNotifier.value]!; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text(t['font_size']!, style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Padding(padding: EdgeInsets.all(30), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, borderRadius: BorderRadius.circular(15)), child: Text(t['sample_text']!, style: TextStyle(color: isDark ? Colors.white : Colors.black))), SizedBox(height: 40), ValueListenableBuilder<double>(valueListenable: fontSizeNotifier, builder: (context, size, _) { return Column(children: [Slider(value: size, min: 12.0, max: 24.0, divisions: 6, activeColor: Colors.blue, onChanged: (val) { fontSizeNotifier.value = val; saveSettings(); }), Text("${size.toInt()}", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey))]); })]))); }); } }

class UserDetailsPage extends StatefulWidget { final String userName; UserDetailsPage({required this.userName}); @override _UserDetailsPageState createState() => _UserDetailsPageState(); }

class _UserDetailsPageState extends State<UserDetailsPage> { 

  File? _image; final ImagePicker _picker = ImagePicker(); String name = "";

  @override void initState() { super.initState(); name = widget.userName; _loadImage(); }

  Future<void> _loadImage() async { final prefs = await SharedPreferences.getInstance(); String? path = prefs.getString('user_image_path'); if (path != null && File(path).existsSync()) { setState(() { _image = File(path); }); } }

  Future<void> _pickImage() async { try { final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery); if (pickedFile != null) { CroppedFile? croppedFile = await ImageCropper().cropImage(sourcePath: pickedFile.path, uiSettings: [AndroidUiSettings(toolbarTitle: 'Crop Image', toolbarColor: Colors.black, toolbarWidgetColor: Colors.white, initAspectRatio: CropAspectRatioPreset.original, lockAspectRatio: false), IOSUiSettings(title: 'Crop Image')]); if (croppedFile != null) { final directory = await getApplicationDocumentsDirectory(); final path = directory.path; final fileName = 'user_profile.jpg'; final newImage = await File(croppedFile.path).copy('$path/$fileName'); final prefs = await SharedPreferences.getInstance(); await prefs.setString('user_image_path', newImage.path); setState(() { _image = newImage; }); } } } catch (e) {} } 

  void _removeImage() async { final prefs = await SharedPreferences.getInstance(); await prefs.remove('user_image_path'); setState(() { _image = null; }); } 

  // FIX: GLASSY PREMIUM EDIT NAME POPUP

  void _editName() {

    TextEditingController controller = TextEditingController(text: name);

    bool isDark = themeNotifier.value;

    showGeneralDialog(

      context: context,

      barrierDismissible: true,

      barrierLabel: '',

      transitionDuration: Duration(milliseconds: 300),

      pageBuilder: (ctx, anim1, anim2) => Container(),

      transitionBuilder: (ctx, anim1, anim2, child) {

        return Transform.scale(scale: anim1.value, child: AlertDialog(

          backgroundColor: isDark ? Color(0xFF1E1E1E) : Colors.white,

          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),

          title: Text("Edit Name", style: TextStyle(color: isDark ? Colors.white : Colors.black)),

          content: TextField(controller: controller, autofocus: true, style: TextStyle(color: isDark ? Colors.white : Colors.black), decoration: InputDecoration(hintText: "Enter Name", hintStyle: TextStyle(color: Colors.grey), focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue)))),

          actions: [

            TextButton(onPressed: () => Navigator.pop(context), child: Text("Cancel", style: TextStyle(color: Colors.grey))),

            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, shape: StadiumBorder()), onPressed: () async {

              if (controller.text.isNotEmpty) {

                final prefs = await SharedPreferences.getInstance();

                await prefs.setString('userName', controller.text);

                setState(() { name = controller.text; });

                Navigator.pop(context);

              }

            }, child: Text("Save", style: TextStyle(color: Colors.white)))

          ],

        ));

      }

    );

  }

  

  @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { var t = localized[langNotifier.value]!; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Center(child: Column(children: [SizedBox(height: 40), Text(t['profile']!, style: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), SizedBox(height: 40), GestureDetector(onTap: _pickImage, child: Container(width: 120, height: 120, decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, shape: BoxShape.circle, border: Border.all(color: Colors.blue, width: 2), image: _image != null ? DecorationImage(image: FileImage(_image!), fit: BoxFit.cover) : null), child: _image == null ? Icon(Icons.add_a_photo, size: 40, color: Colors.grey) : null)), SizedBox(height: 15), Text(t['change_photo']!, style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold)), if (_image != null) TextButton(onPressed: _removeImage, child: Text(t['remove_photo']!, style: TextStyle(color: Colors.red))), SizedBox(height: 20), Container(margin: EdgeInsets.symmetric(horizontal: 40), padding: EdgeInsets.all(20), decoration: BoxDecoration(color: isDark ? Colors.grey[900] : Colors.white, borderRadius: BorderRadius.circular(20)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.person, color: Colors.grey), SizedBox(width: 15), Text(name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), SizedBox(width: 10), GestureDetector(onTap: _editName, child: Icon(Icons.edit, size: 18, color: Colors.blue))])), SizedBox(height: 40), TextButton.icon(icon: Icon(Icons.delete_forever, color:Colors.red), label: Text(t['logout']!, style: TextStyle(color: Colors.red, fontSize: 16, fontWeight: FontWeight.bold)), onPressed: () async { final prefs = await SharedPreferences.getInstance(); await prefs.remove('userName'); Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => OnboardingScreen()), (Route<dynamic> route) => false); })])));}); } }

class PrivacyPage extends StatelessWidget { @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text("Privacy Policy", style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Padding(padding: EdgeInsets.all(20), child: Text("Your privacy is important to us. Tamil Needhi AI does not store your personal data on external servers. All chat history is stored locally on your device.", style: TextStyle(fontSize: 16, color: isDark ? Colors.white : Colors.black, height: 1.5)))); }); } }

// FIX: NEW SUPPORT EMAIL

class HelpPage extends StatelessWidget { @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text("Help & Support", style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Padding(padding: EdgeInsets.all(20), child: Column(children:[Text("Contact support for assistance.", style: TextStyle(fontSize: 16, color: isDark ? Colors.white : Colors.black, height: 1.5)), SizedBox(height: 20), ElevatedButton.icon(icon: Icon(Icons.email), label: Text("Email Support"), onPressed: () => launchUrl(Uri.parse("mailto:tamilneedhiai.help@gmail.com")))]))); }); } }

class HistoryPage extends StatelessWidget { final VoidCallback clearHistory; HistoryPage({required this.clearHistory}); @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { var t = localized[langNotifier.value]!; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(title: Text(t['history']!, style: TextStyle(color: isDark ? Colors.white : Colors.black)), backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.history_toggle_off, size: 80, color: Colors.grey), SizedBox(height: 20), Text(t['history_desc']!, style: TextStyle(color: Colors.grey)), SizedBox(height: 40), ElevatedButton.icon(icon: Icon(Icons.delete), label: Text(t['clear_chat']!), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white, padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15)), onPressed: () { clearHistory(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t['deleted']!))); Navigator.pop(context); })])));}); } }

class AboutPage extends StatelessWidget { @override Widget build(BuildContext context) { return ValueListenableBuilder<bool>(valueListenable: themeNotifier, builder: (context, isDark, _) { var t = localized[langNotifier.value]!; return Scaffold(backgroundColor: isDark ? Colors.black : Color(0xFFF2F2F7), appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back_ios_new, color: isDark ? Colors.white : Colors.black), onPressed: () => Navigator.pop(context))), body: Center(child: Padding(padding: EdgeInsets.all(30), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.balance, size: 80, color: isDark ? Colors.white : Colors.black), SizedBox(height: 20), Text("Tamil Needhi AI", style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold, color: isDark ? Colors.white : Colors.black)), SizedBox(height: 10), Text(t['version']!, style: TextStyle(color: Colors.grey)), SizedBox(height: 30), Text(t['about_desc']!, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: isDark ? Colors.white70 : Colors.black87, height: 1.5))]))));}); } }
